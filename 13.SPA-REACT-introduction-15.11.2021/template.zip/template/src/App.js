import './App.css';

function App() {
  return (
    <div className="App">
     <h1> React Intro</h1>     
    </div>
  );
}

export default App;
